package team07.Banking_System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
